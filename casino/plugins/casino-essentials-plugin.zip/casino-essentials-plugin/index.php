<?php
/**
 * Plugin Name: casino-essentials-plugin
 * Description: The very first plugin that I have ever created.
 * Version: 1.0
 * Author: Yashesh
 * Author URI: http://www.sohamwebs.com
 */

 //custom post types
    function casiono_custom_post(){
        //custom poat for BGimage/s
        register_post_type('BGimage', array(
            'labels' => array(
                'name' => __('Hero', 'casino'),
                'singular_name' => __('Hero', 'casino')
            ),
            'public' => true,
            'show_ui' => true,
            'supports' => array('title', 'editor', 'thumbnail', 'custom-fields'),
            'show_in_rest' => true
        ));

        //About Us custom types
        register_post_type('about', array(
            'labels' => array(
                'name' => __('About', 'casino'),
                'singular_name' => __('About', 'casino')
            ),
            'public' => true,
            'show_ui' => true,
            'supports' => array('subtitle', 'title', 'editor', 'thumbnail', 'custom-fields'),
            'show_in_rest' => true
        ));


        //Why Us custom types
        register_post_type('why', array(
            'labels' => array(
                'name' => __('Why us', 'casino'),
                'singular_name' => __('Why', 'casino')
            ),
            'public' => true,
            'show_ui' => true,
            'supports' => array('subtitle', 'title', 'editor', 'thumbnail', 'custom-fields'),
            'show_in_rest' => true
        ));

        //Casino Table custom types
        register_post_type('casino_table', array(
            'labels' => array(
                'name' => __('Casino Table', 'casino'),
                'singular_name' => __('Casino Table', 'casino')
            ),
            'public' => true,
            'show_ui' => true,
            'supports' => array('subtitle', 'title', 'editor', 'thumbnail', 'custom-fields'),
            'show_in_rest' => true
        ));
    }

    add_action('init', 'casiono_custom_post');